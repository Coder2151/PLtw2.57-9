// pltw 2.5.8 step 1:
public class MediaLibRunnerStatic
{
  public static void main(String[] args)
  {
    System.out.println(MediaLib.getOwner() + "'s Library");
  }
}